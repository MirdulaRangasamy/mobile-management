package com.exterro.mobile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileManagementApplication.class, args);
	}

}
