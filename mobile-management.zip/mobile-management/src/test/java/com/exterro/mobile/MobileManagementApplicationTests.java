package com.exterro.mobile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
